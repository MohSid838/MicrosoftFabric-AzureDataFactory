-- Auto Generated (Do not modify) 2E4895E2B04BD2EA6DB0254593C8A0167D5AE9EFD842F27F01FB441B00360F39

create VIEW Sales.vw_staging_salesdata

AS

SELECT * from [Sales_Lakehouse].[dbo].[new_salesdata]
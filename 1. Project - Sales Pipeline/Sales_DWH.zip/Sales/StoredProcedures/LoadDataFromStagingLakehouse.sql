CREATE PROCEDURE Sales.LoadDataFromStagingLakehouse
    @OrderYear INT
 AS
 BEGIN
 	INSERT INTO Sales.Dim_Customer (CustomerID, CustomerName, FirstName , LastName, EmailAddress)
     SELECT DISTINCT CustomerName, CustomerName,FirstName , LastName,  EmailAddress
     FROM [Sales].[vw_staging_salesdata]
     WHERE YEAR(OrderDate) = @OrderYear
     AND NOT EXISTS (
         SELECT 1
         FROM Sales.Dim_Customer
         WHERE Sales.Dim_Customer.CustomerName = Sales.[vw_staging_salesdata].CustomerName
         AND Sales.Dim_Customer.EmailAddress = Sales.[vw_staging_salesdata].EmailAddress
     );
        
     -- Load data into the Item dimension table
     INSERT INTO Sales.Dim_Item (ItemID, ItemName)
     SELECT DISTINCT Item, Item
     FROM [Sales].[vw_staging_salesdata]
     WHERE YEAR(OrderDate) = @OrderYear
     AND NOT EXISTS (
         SELECT 1
         FROM Sales.Dim_Item
         WHERE Sales.Dim_Item.ItemName = Sales.[vw_staging_salesdata].Item
     );
        
     -- Load data into the Sales fact table
     INSERT INTO Sales.Fact_Sales (CustomerID, ItemID, SalesOrderNumber, SalesOrderLineNumber, OrderDate, Quantity, TaxAmount, UnitPrice, [Year], [Month])
     SELECT CustomerName, Item, SalesOrderNumber, CAST(SalesOrderLineNumber AS INT),
      CAST(OrderDate AS DATE), CAST(Quantity AS INT), 
     CAST(TaxAmount AS FLOAT), CAST(UnitPrice AS FLOAT), 
     [Year], [Month]
     FROM [Sales].[vw_staging_salesdata]
     WHERE YEAR(OrderDate) = @OrderYear;
 END